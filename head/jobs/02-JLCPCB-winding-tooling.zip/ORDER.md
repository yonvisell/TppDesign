# Winding fixture PCB jobs

Order five R2K-jig boards in 1.60 mm standard two-layer FR-4 and five R2K-frame boards in 0.80 mm standard two-layer FR-4. Both outlines are 40.00×25.50. The two nested Gerber archives are separate designs. One bench tool uses one base and two identical sliding plates.

The base carries four Ø1.40 stack fixture holes, two Ø2.10 clamp holes, two Ø6.00 reliefs for the plate-lock nuts, the routed cable slot and six rounded guide clearance windows. The frame opening is 22.30×18.30. Each frame has 24 Ø0.40 finished plated guide bores in Ø0.75 lands, two Ø2.40 round lock holes and two 2.20×3.40 nonplated slots. Confirm finished bore sizes and thickness. Leave the functional drill and edge geometry unchanged. The owner mounts and locks the 24 smooth Ø0.30 pins by offsetting two plates. The final guide position is set optically at wire height and the plates clamped to the base. A removable 0.20 stainless U-shaped hold tool is a laboratory item in packet 04.
