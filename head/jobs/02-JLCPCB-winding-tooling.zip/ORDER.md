# Two separate bare PCB fabrication jobs

Order R2J-jig-Gerber.zip as a 1.60 mm two-layer winding base, and R2J-frame-Gerber.zip as a 0.80 mm two-layer guide frame. The two ZIPs are independent board designs. Request five of each. Outside size 40.00 × 25.50 mm. Use conventional FR-4, standard finish and top legend. The owner installs all pins, fasteners and clamps after fabrication.

Base: four Ø0.65 unplated datum bores, two Ø2.10 unplated M2 mounting holes, cable slot and six 5.55 × 2.90 R0.60 routed clearance windows. Frame: 22.30 × 16.90 mm central opening, 24 Ø0.40 finished plated guide seats (0.75 mm pads) and two 2.20 × 3.40 mm nonplated clamp slots. Confirm the finished Ø0.40 holes accept 0.30 mm smooth pins and retain sufficient annular ring. No component assembly.
